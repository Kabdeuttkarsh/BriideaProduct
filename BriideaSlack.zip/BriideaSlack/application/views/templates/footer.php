<style type="text/css">
  
.chat-window{
    bottom:0;
    position:fixed;
    float:right;
    margin-left:100px;
    margin-bottom: 50px;
}
.chat-window > div > .panel{
    border-radius: 5px 5px 0 0;
}
.icon_minim{
    padding:2px 10px;
}
.msg_container_base{
  background: #e5e5e5;
  margin: 0;
  padding: 0 10px 10px;
  max-height:300px;
  overflow-x:hidden;
}

.msg_container_base  >.scrollbar{
    display: none;
}
.top-bar {
  background: #666;
  color: white;
  padding: 10px;
  position: relative;
  overflow: hidden;
}
.msg_receive{
    padding-left:0;
    margin-left:0;
}
.msg_sent{
    padding-bottom:20px !important;
    margin-right:0;
   
}
.messages {
  background: white;
  padding: 10px;
  border-radius: 2px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  max-width:100%;
}
.messages > p {
    font-size: 13px;
    margin: 0 0 0.2rem 0;
  }
.messages > time {
    font-size: 11px;
    color: #ccc;
}
.msg_container {
    padding: 10px;
    overflow: hidden;
    display: flex;
}
img {
    display: block;
    width: 100%;
}
.avatar {
    position: relative;
}
.base_receive > .avatar:after {
    content: "";
    position: absolute;
    top: 0;
    right: 0;
    width: 0;
    height: 0;
    border: 5px solid #FFF;
    border-left-color: rgba(0, 0, 0, 0);
    border-bottom-color: rgba(0, 0, 0, 0);
}

.base_sent {
  justify-content: flex-end;
  align-items: flex-end;

}
.base_sent > .avatar:after {
    content: "";
    position: absolute;
    bottom: 0;
    left: 0;
    width: 0;
    height: 0;
    border: 5px solid white;
    border-right-color: transparent;
    border-top-color: transparent;
    box-shadow: 1px 1px 2px rgba(black, 0.2); // not quite perfect but close
}

.msg_sent > time{
    float: right;
}



.msg_container_base::-webkit-scrollbar-track
{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
    background-color: #F5F5F5;
}

.msg_container_base::-webkit-scrollbar
{
    width: 12px;
    background-color: #F5F5F5;
}

.msg_container_base::-webkit-scrollbar-thumb
{
    -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
    background-color: #555;
}

.btn-group.dropup{
    position:fixed;
    left:0px;
    bottom:0;
}
</style>

<div class="container" id="chatMsgWindow">
   <!--  <div class="row chat-window col-xs-5 col-md-3" id="chat_window_1" style="margin-right:10px;" >
        <div class="col-xs-12 col-md-12">
          <div class="panel panel-default">
                <div class="panel-heading top-bar">
                    <div class="col-md-8 col-xs-8">
                        <h3 class="panel-title"><span class="glyphicon glyphicon-comment"></span> Chat - Miguel</h3>
                    </div>
                    <div class="col-md-4 col-xs-4" style="text-align: right;">
                        <a href="#"><span id="minim_chat_window" class="glyphicon glyphicon-minus icon_minim"></span></a>

                        <a href="#"><span id="max_chat_window" class="glyphicon glyphicon-fullscreen icon_maxim"></span></a>
                        
                        <a href="#"><span class="glyphicon glyphicon-remove icon_close" data-id="chat_window_1"></span></a>
                    </div>
                </div>
                <div class="panel-body msg_container_base">
                    <div class="row msg_container base_sent">
                        <div class="col-md-10 col-xs-10">
                            <div class="messages msg_sent">
                                <p>that mongodb thing looks good, huh?
                                tiny master db, and huge document store</p>
                                <time datetime="2009-11-13T20:00">Timothy • 51 min</time>
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-2 avatar">
                            <img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">
                        </div>
                    </div>
                    <div class="row msg_container base_receive">
                        <div class="col-md-2 col-xs-2 avatar">
                            <img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">
                        </div>
                        <div class="col-md-10 col-xs-10">
                            <div class="messages msg_receive">
                                <p>that mongodb thing looks good, huh?
                                tiny master db, and huge document store</p>
                                <time datetime="2009-11-13T20:00">Timothy • 51 min</time>
                            </div>
                        </div>
                    </div>
                   
                    <div class="row msg_container base_sent">
                        <div class="col-md-10 col-xs-10 ">
                            <div class="messages msg_sent">
                                <p>that mongodb thing looks good, huh?
                                tiny master db, and huge document store</p>
                                <time datetime="2009-11-13T20:00">Timothy • 51 min</time>
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-2 avatar">
                            <img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">
                        </div>
                    </div>
                </div>
                <div class="panel-footer">
                    <div class="input-group">
                        <input id="btn-input" type="text" class="form-control input-sm chat_input" placeholder="Write your message here..." />
                        <span class="input-group-btn">
                        <button class="btn btn-primary btn-sm" id="btn-chat">Send</button>
                        </span>
                    </div>
                </div>
        </div>
        </div>
    </div> -->
    
    <!-- <div class="btn-group dropup">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
            <span class="glyphicon glyphicon-cog"></span>
            <span class="sr-only">Toggle Dropdown</span>
        </button>
        <ul class="dropdown-menu" role="menu">
            <li><a href="#" id="new_chat"><span class="glyphicon glyphicon-plus"></span> Novo</a></li>
            <li><a href="#"><span class="glyphicon glyphicon-list"></span> Ver outras</a></li>
            <li><a href="#"><span class="glyphicon glyphicon-remove"></span> Fechar Tudo</a></li>
            <li class="divider"></li>
            <li><a href="#"><span class="glyphicon glyphicon-eye-close"></span> Invisivel</a></li>
        </ul>
    </div>
     -->


</div>

<script type="text/javascript">
  
  showUserListforChat();

  function showUserListforChat(argument) {
    
     $.ajax({
                type: 'ajax',
                url: "<?php echo base_url() ?>api/User/showUserListforChat/",
                async: false,
                method:'get',
                dataType: 'json',
                success: function(response) {
                    // body...
                    data=response.data;
                    var html="";
                  
                    for (var i = 0; i < data.length; i++) {
                      var x=i+1;
                      html+='<li id="manageUserSubNav" style="padding: 5px 5px 5px 15px; display: block; font-size: 14px;">'+

                        '<a href="javascript:;"  class="item-OpenChatWindow" data="'+data[i].id+'" firstname="'+data[i].firstname+'"  lastname="'+data[i].lastname+'">'+

                          '<i class="fa fa-circle-o"></i> '+data[i].firstname+' '+data[i].lastname+'</a></li>';
                    }
                 
                   $('#showUserListforChat').html(html);
                         },
                     error: function(response){
                       var data =JSON.parse(response.responseText);
                       toastr.error(data.message);
                        }

            });


  }
  
</script>


<script type="text/javascript">
  $(document).on('click', '.panel-heading span.icon_minim', function (e) {
    var $this = $(this);
    if (!$this.hasClass('panel-collapsed')) {
        $this.parents('.panel').find('.panel-body').slideUp();
        $this.addClass('panel-collapsed');
        $this.removeClass('glyphicon-minus').addClass('glyphicon-plus');
    } else {
        $this.parents('.panel').find('.panel-body').slideDown();
        $this.removeClass('panel-collapsed');
        $this.removeClass('glyphicon-plus').addClass('glyphicon-minus');
    }
});


$(document).on('focus', '.panel-footer input.chat_input', function (e) {
    var $this = $(this);
    if ($('#minim_chat_window').hasClass('panel-collapsed')) {
        $this.parents('.panel').find('.panel-body').slideDown();
        $('#minim_chat_window').removeClass('panel-collapsed');
        $('#minim_chat_window').removeClass('glyphicon-plus').addClass('glyphicon-minus');
    }
});

$(document).on('click', '#new_chat', function (e) {
    var size = $( ".chat-window:last-child" ).css("margin-left");
    if(size){
            size_total = parseInt(size) + 500;
    }
    else{
          size_total =  500;
    }

  //  alert(size_total);
    var clone = $( "#chat_window_1" ).clone().appendTo( ".container" );
    clone.css("margin-left", size_total);
});

$(document).on('click', '.icon_close', function (e) {
    //$(this).parent().parent().parent().parent().remove();
    $( "#chat_window_1" ).remove();
});


$('#main_div_for_ref').on('click', '.item-OpenChatWindow', function(){
    var id = $(this).attr('data');
    var firstname = $(this).attr('firstname');
    var lastname = $(this).attr('lastname');

    $.ajax({
        type: 'ajax',
        method: 'get',
        url: '<?php echo base_url(); ?>api/UserChat/row',
        data:{'id': id},  
        async: false,
        dataType: 'json',
        success: function(response){
            data=response.data;
            var html="";
             
            if(response.status){

                html=showWindow(firstname,lastname,id,data);
               

                $('#chatMsgWindow').html(html);
              

                // $('#msg_container_base').stop().animate({
                //   scrollTop: $("#msg_container_base")[0].scrollHeight
                // }, 800);

                    
                     $('#msg_container_base').animate({scrollTop: 999999}).delay(0);
                     $('#msg_container_base').animate({scrollTop: 999999});

            }

            else{

                  html=showWindow(firstname,lastname,id,data=null);

                
                   $('#chatMsgWindow').html(html);
                
                //     $('#msg_container_base').stop().animate({
                //   scrollTop: $("#msg_container_base")[0].scrollHeight
                // }, 800);

                $('#msg_container_base').animate({scrollTop: 999999}).delay(0);
                $('#msg_container_base').animate({scrollTop: 999999});
               
            }
           
           
        },
          error: function(response){
       
               var data =JSON.parse(response.responseText);
               toastr.error(data.message);
        }
    });

});



</script>

<script type="text/javascript">

    function showWindow(firstname,lastname,id,messages) {

        var html='';
        var size = $( ".chat-window:last-child" ).css("margin-left");
       
        if(size){
         
           size_total = parseInt(size) + 500;
       
        }
        
        else{

           size_total =  500;
      
        }
       
        var clone = $( "#chat_window_1" ).clone().appendTo( ".container" );
        clone.css("margin-left", size_total);
        

        html+='<div class="row chat-window col-xs-5 col-md-3" id="chat_window_1" style="margin-right:10px;" >'+
        '<div class="col-xs-12 col-md-12">'+
          '<div class="panel panel-default">'+
                '<div class="panel-heading top-bar">'+
                    '<div class="col-md-8 col-xs-8">'+
                        '<h3 class="panel-title"><span class="glyphicon glyphicon-comment"></span> '+firstname+' '+lastname+'</h3>'+
                    '</div>'+
                    '<div class="col-md-4 col-xs-4" style="text-align: right;">'+
                        '<a href="#"><span id="minim_chat_window" class="glyphicon glyphicon-minus icon_minim"></span></a>'+

                        '<a href="#"><span id="max_chat_window" class="glyphicon glyphicon-fullscreen icon_maxim"></span></a>'+
                        
                        '<a href="#"><span class="glyphicon glyphicon-remove icon_close" data-id="chat_window_1"></span></a>'+
                    '</div>'+
                '</div>'+

                '<div class="panel-body msg_container_base" id="msg_container_base">';
                  
                if(messages){
                     for (var i = 0; i < messages.length; i++) {

                    // messages[i]
                    if(messages[i].sender_message_id!=id){
                       html+='<div class="row msg_container base_sent">'+
                                            '<div class="col-md-10 col-xs-10">'+
                                                '<div class="messages msg_sent" style=" background-color: #dcf8c6;">'+
                                                    '<p>'+messages[i].message+'</p>'+
                                                    '<time datetime="'+messages[i].message_time+'">'+messages[i].message_time+'</time>'+
                                                '</div>'+
                                           ' </div>'+
                                           ' <div class="col-md-2 col-xs-2 avatar">'+
                                                '<img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">'+
                                            '</div>'+
                                        '</div>';

                    }

                    else{


                         html+= '<div class="row msg_container base_receive">'+
                           ' <div class="col-md-2 col-xs-2 avatar">'+
                                '<img src="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg" class=" img-responsive ">'+
                            '</div>'+
                            '<div class="col-md-10 col-xs-10">'+
                                '<div class="messages msg_receive">'+
                                   '<p>'+messages[i].message+'</p>'+
                                    '<time datetime="2009-11-13T20:00">'+messages[i].message_time+'</time>'+
                                '</div>'+
                           ' </div>'+
                       ' </div>';
                    }

                }

                }
               
                 html+='</div>'+
                '<div class="panel-footer">'+
                   ' <div class="input-group">'+
                     
                        '<input id="firstnameSend" name="firstnameSend" type="hidden" class="form-control input-sm chat_input" value="'+firstname+'" />'+
                      
                        '<input id="lastnameSend" name="lastnameSend" type="hidden" class="form-control input-sm chat_input" value="'+lastname+'" />'+

                        '<input id="btn-inputID" name="btn-inputID" type="hidden" class="form-control input-sm chat_input" value="'+id+'" />'+

                        '<input id="btn-input" type="text" name="btn-input" class="form-control input-sm chat_input" placeholder="Write your message here..." />'+
                        '<span class="input-group-btn">'+
                        '<a href="javascript:;" class="btn btn-primary btn-sm btnSendMessage">Send</a>'+
                        '</span>'+
                    '</div>'+
               ' </div>'+
       ' </div>'+
        '</div>'+
     ' </div>';

     return html;
    }

</script>

<script type="text/javascript">


var open_chat_of_id='<?php echo $this->session->userdata('id');?>';
var open_chat_of_fname='<?php echo $this->session->userdata('firstname');?>';
var open_chat_of_lname='<?php echo $this->session->userdata('lastname');?>';

  // main_div_for_ref
$('#main_div_for_ref').on('click', '.btnSendMessage', function(){
    var typed_message = $('input[name=btn-input]').val();
    var receiver_id = $('input[name=btn-inputID]').val();
    var firstnameSend = $('input[name=firstnameSend]').val();
    var lastnameSend = $('input[name=lastnameSend]').val();
   
    if(typed_message==''){
        toastr.error("Please Enter message and then send");
    }  

    else if (receiver_id=='') {
            toastr.error("Please try again");
    }

    else{

        $.ajax({
            type: 'ajax',
            method:'post',
            url: '<?php echo base_url();?>api/UserChat/sendUserMessage',
            data: {'typed_message':typed_message,'receiver_id':receiver_id},
            async: false,
            dataType: 'json',
            success: function(response){

                    if (response.status) {
                       var message_id=response.data;
                        refreshChat(receiver_id,firstnameSend,lastnameSend);
                   
                        if(response.is_receiver_online==1){
                         

                         refreshReceiversChat(open_chat_of_id,open_chat_of_fname,open_chat_of_lname,receiver_id,message_id);


                        }

                    }
                    else{
                       toastr.error(response.message);
                    }
                    
                 
            },

          error: function(response){
                   var data =JSON.parse(response.responseText);
                   toastr.error(data.message);
            }

        });

    }


});


function refreshReceiversChat(open_chat_of_id,open_chat_of_fname,open_chat_of_lname,receiver_id,message_id) {

     $.ajax({
        type: 'ajax',
        method: 'get',
        url: '<?php echo base_url(); ?>api/UserChat/openChatReceiverAfterMessageSent',
        data:{'open_chat_of_id': open_chat_of_id,'open_chat_of_fname':open_chat_of_fname,
              'open_chat_of_lname': open_chat_of_lname,'receiver_id':receiver_id,
              'message_id':message_id
            },  
        async: false,
        dataType: 'json',
        success: function(response){
            data=response.data;
            var html="";
             
            if(response.status){

                html=showWindow(response.openChatOFFname,response.openChatOFLname,
                                response.openChatOFID,response.ChatMessage);
               

                $('#chatMsgWindow').html(html);

                $('#msg_container_base').animate({scrollTop: 999999}).delay(0);
                $('#msg_container_base').animate({scrollTop: 999999});
            }

            else{
                 
            }
           
           
        },
          error: function(response){
       
              // var data =JSON.parse(response.responseText);
               //toastr.error(data.message);
        }
    });


    
}

function  refreshChat(id,firstname,lastname) {
    $.ajax({
        type: 'ajax',
        method: 'get',
        url: '<?php echo base_url(); ?>api/UserChat/row',
        data:{'id': id},  
        async: false,
        dataType: 'json',
        success: function(response){
            data=response.data;
            var html="";
             
            if(response.status){

                html=showWindow(firstname,lastname,id,data);
               

                $('#chatMsgWindow').html(html);

                  $('#msg_container_base').animate({scrollTop: 999999}).delay(0);
                  $('#msg_container_base').animate({scrollTop: 999999});
            }

            else{
                  html=showWindow(firstname,lastname,id,null);

                
                  $('#chatMsgWindow').html(html);

                    $('#msg_container_base').animate({scrollTop: 999999}).delay(0);
                   $('#msg_container_base').animate({scrollTop: 999999});
            }
           
           
        },
          error: function(response){
       
               var data =JSON.parse(response.responseText);
               toastr.error(data.message);
        }
    });

}


</script>

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.1.0
    </div>
    <strong>&copy; 2021 - <?php echo date('Y'); ?> |</strong> All rights
    reserved and Developed by <a href="" target="_BLANK">Uttkarsh Kabde</a>
  </footer>

  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->



</body>
</html>
